import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner input=new Scanner(System.in);
	    System.out.println("Enter the alpahabet :");
	    char alpahabet=input.next().charAt(0);
	    int ascii=(int)alpahabet;
	    System.out.print("Ascii value = ");
	    System.out.print(ascii);
	    
	
}
}
