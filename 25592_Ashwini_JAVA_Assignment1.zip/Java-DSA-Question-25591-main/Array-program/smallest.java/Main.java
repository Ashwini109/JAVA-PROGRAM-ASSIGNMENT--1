import java. util. Arrays;
public class Main
{
	public static void main(String[] args) {
int[] arr = new int[]{ 10,78,96,-8,-5,12,17,12,33,11 };
Arrays.sort(arr);
System.out.print("Smallest element =");
System.out.println(arr[0]);


	}
}

